import argparse
import sys
import json
import re
import time
import urllib.parse as urlparse
from urllib.parse import parse_qs
import http.client

def extract_app_id(play_url):
    parsed = urlparse.urlparse(play_url)
    query_params = parse_qs(parsed.query)
    if 'id' in query_params:
        return query_params['id'][0]
    else:
        print("Invalid Google Play URL: missing 'id' parameter")
        sys.exit(1)

def get_evozi_token():
    conn = http.client.HTTPSConnection("apps.evozi.com")
    conn.request("GET", "/apk-downloader/")
    response = conn.getresponse()
    if response.status != 200:
        print("Failed to retrieve Evozi token.")
        sys.exit(1)
    
    result = response.read().decode()
    conn.close()

    for line in result.split('\n'):
        if "$('#forceRefetch').is(':checked')}" in line:
            split_line = line.split(':')
            epoch_key = split_line[0].strip().split('{')[1]
            epoch = split_line[1].strip().split(',')[0]
            id_key = split_line[1].strip().split(',')[1]
            token_key = split_line[2].strip().split(',')[1]
            token_variable = split_line[3].strip().split(',')[0]
            
            token_match = re.findall(r"{}  = '([^']+)'".format(token_variable), result)
            if token_match:
                token = token_match[0]
                return id_key, {epoch_key: epoch, id_key: None, token_key: token}

    print("Failed to retrieve Evozi token.")
    sys.exit(1)

def get_download_url(app_id, id_key, data):
    evozi_url = "/download"
    data[id_key] = app_id
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    # Encode form data
    encoded_data = urlparse.urlencode(data)

    conn = http.client.HTTPSConnection("api-apk.evozi.com")
    conn.request("POST", evozi_url, body=encoded_data, headers=headers)
    response = conn.getresponse()
    
    if response.status != 200:
        print("Failed to retrieve download URL.")
        sys.exit(1)

    try:
        result = json.loads(response.read().decode())
        conn.close()
        return 'https:' + result['url']
    except (json.JSONDecodeError, KeyError):
        print("Failed to retrieve download URL.")
        sys.exit(1)

def main():
    # Parse arguments
    parser = argparse.ArgumentParser(description='A script to get the APK download link from api-apk.evozi.com')
    parser.add_argument('--type', choices=['id', 'url'], help='Is input a Google Play URL, or the app ID?', default='url')
    parser.add_argument('query', type=str, help='The URL or ID of the app depending on mode parameter.')
    args = parser.parse_args()

    # URL or ID?  
    if args.type == 'url':  
        try:  
            app_id = extract_app_id(args.query)  
        except Exception:  
            print('Query parameter does not seem to be a proper Google Play URL')  
            sys.exit(1)  
    else:  
        app_id = args.query.strip().replace('"', '')  

    # Get URL  
    id_key, data = get_evozi_token()  
    print(get_download_url(app_id, id_key, data))

if __name__ == '__main__':
    main()