import sys
import http.client
import urllib.parse
import re

class APKPure:
    def __init__(self, pkg_name: str):
        self.pkg_name = pkg_name
        self.base_url = "apkpure.net"
        self.cdn_url = f"/b/APK/{pkg_name}?version=latest"
        self.search_url = f"/search?q={urllib.parse.quote(pkg_name)}"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
            "Referer": "https://apkpure.net/",
        }

    def get_download_url(self):
        """Mendapatkan URL download APK versi terbaru."""
        conn = http.client.HTTPSConnection("d.cdnpure.com")
        conn.request("HEAD", self.cdn_url, headers=self.headers)
        response = conn.getresponse()

        if response.status in [301, 302]:
            download_url = response.getheader("Location")
            conn.close()
            return download_url if download_url and "apkpure.com" not in download_url else None
        conn.close()
        return None

    def get_available_versions(self):
        """Mendapatkan daftar versi yang tersedia di APKPure."""
        print("\nFetching available versions...")
        conn = http.client.HTTPSConnection(self.base_url)
        conn.request("GET", self.search_url, headers=self.headers)
        response = conn.getresponse()
        html_data = response.read().decode("utf-8")
        conn.close()

        search_results = re.findall(r'<a class="apk-item".*?href="(.*?)".*?data-dt-pkg="(.*?)"', html_data)
        versions_info = []

        for apk_link, apk_package_name in search_results:
            if apk_package_name == self.pkg_name:
                versions_url = apk_link + "/versions"

                conn = http.client.HTTPSConnection(self.base_url)
                conn.request("GET", versions_url, headers=self.headers)
                response = conn.getresponse()
                versions_html = response.read().decode("utf-8")
                conn.close()

                versions_list = re.findall(
                    r'<li class="version dt-version-item.*?">.*?<span class="name one-line">(.*?)</span>.*?<a class="dt-version-icon".*?href="(.*?)"',
                    versions_html, re.DOTALL
                )
                for version_number, version_link in versions_list:
                    # Menghapus tag HTML <small>...</small> dari teks versi
                    version_number_clean = re.sub(r'<.*?>', '', version_number).strip()
                    versions_info.append((version_number_clean, "https://" + self.base_url + version_link))
                break
        
        return versions_info

if __name__ == "__main__":
    if "--id" in sys.argv:
        try:
            package_name = sys.argv[sys.argv.index("--id") + 1]
        except IndexError:
            print("Error: Package name tidak diberikan!")
            sys.exit(1)
        
        apkpure = APKPure(package_name)

        print(f"Mencari URL download untuk {package_name}...")
        download_url = apkpure.get_download_url()

        if download_url:
            print(f"URL Download APK (Latest): {download_url}")
        else:
            print("APK tidak ditemukan atau tidak tersedia untuk diunduh langsung.")

        available_versions = apkpure.get_available_versions()
        if available_versions:
            print("\nAvailable Versions:")
            for version, link in available_versions:
                print(f"Version: {version}\nUrl: {link}")
        else:
            print("Tidak ada versi yang ditemukan.")
    else:
        print("Usage:")
        print("python app.py --id <package_name>")