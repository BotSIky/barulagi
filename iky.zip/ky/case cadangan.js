case 'lyrics': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide the name of the song to get its lyrics.\n\nExample: ${prefix + command} Shape of You`);
    }

    const songName = encodeURIComponent(text);

    axios.get(`https://api.lyrics.ovh/v1/${songName}`)
        .then(response => {
            const lyrics = response.data.lyrics;
            if (lyrics) {
                const formattedLyrics = lyrics.replace(/\n/g, '\n\n');
                m.reply(`Lyrics for "${text}":\n\n${formattedLyrics}`);
            } else {
                m.reply(`No lyrics found for "${text}".`);
            }
        })
        .catch(error => {
            m.reply('Failed to fetch lyrics. Please try again later.');
        });
}
break;
case 'yesus': case 'bible': {
		if (!text) throw `Kenapa Wahai Umat Bumi Kalo Kamu Ingin Bertanya Silahkan Tanya Saja`			
		m.reply('Patience, O Earthlings')
			var { data } = await axios.get(`https://api.ibeng.tech/api/ai/gpt4jesus?query=${text}&apikey=8llTZ5lQuj`)
			m.reply(`${data.data.response}`.trim())
			}
			break
			
			     // Push Message To Console && Auto Read
        if (m.message) {
            sky.readMessages([m.key])
            console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
        }